package com.spring.rest.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class courseEntity {
	
	@Id
	private long cid;
	private String cname;
	private String description;
	
	public courseEntity() {
		
	}

	public courseEntity(long cid, String cname, String description) {
		
		this.cid = cid;
		this.cname = cname;
		this.description = description;
	}

	public long getCid() {
		return cid;
	}

	public void setCid(long cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "courseEntity [cid=" + cid + ", cname=" + cname + ", description=" + description + "]";
	}
	
	
	
	
	

}
