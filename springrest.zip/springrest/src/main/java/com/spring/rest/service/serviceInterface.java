package com.spring.rest.service;

import java.util.List;

//import org.springframework.stereotype.Service;

import com.spring.rest.entities.courseEntity;


public interface serviceInterface {
	
	public courseEntity add(courseEntity course);
	public List<courseEntity> fetchdata();
	public courseEntity update(courseEntity course);
	public courseEntity getonedata(long courseid);
	public void deletedata(long courseid);

}
