package com.spring.rest.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.rest.dao.daoclass;
import com.spring.rest.entities.courseEntity;
import com.spring.rest.service.serviceInterface;

@Service
public class serviceimpl implements serviceInterface
{
	@Autowired
	private daoclass dao;

	@Override
	public courseEntity add(courseEntity course) {
		
		dao.save(course);
		return course;
	}

	@Override
	public List<courseEntity> fetchdata() {
	return dao.findAll();
	}

	@Override
	public courseEntity update(courseEntity course) {
		
				return dao.save(course);
	}

	@Override
	public courseEntity getonedata(long courseid) {
		
		return dao.findById(courseid).get();
	}

	@Override
	public void deletedata(long courseid)
	{	
	    dao.deleteById(courseid);
	}
	
	
	

}
