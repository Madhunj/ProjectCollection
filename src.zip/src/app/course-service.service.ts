import { Injectable } from '@angular/core';
import { from } from 'rxjs';
import { HttpClient,HttpHeaders,HttpParams} from '@angular/common/http'
import { course } from 'src/app/course';

@Injectable({
  providedIn: 'root'
})
export class CourseServiceService {

  constructor(private http : HttpClient) { }

  adddataintodatabase(cc : course)
  {
    const httpheader = new HttpHeaders();
    httpheader.append('content-type','application/json');
    return this.http.post('http://localhost:8080/addcourse',cc,{headers : httpheader});
  }

  fetchdata()
  {
    const httpheader = new HttpHeaders();
    httpheader.append('content-type','application/json');
    return this.http.get('http://localhost:8080/getcourses',{headers : httpheader});
  }

}
