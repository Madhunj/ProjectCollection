import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { course } from 'src/app/course';
import { CourseServiceService} from '../course-service.service';


@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  
  
  constructor(private service : CourseServiceService) {
    
   }
       
  ngOnInit(): void {
  }
      courselist:any;
  adddata(form : NgForm)
  {
   const cc:course  = new course(form.value.id,form.value.name,form.value.description);
    return this.service.adddataintodatabase(cc).subscribe(data=>
      {
        this.courselist = data;
      })
  }

}
