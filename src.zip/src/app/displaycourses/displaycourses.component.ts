import { Component, OnInit } from '@angular/core';
import { CourseServiceService} from '../course-service.service'

@Component({
  selector: 'app-displaycourses',
  templateUrl: './displaycourses.component.html',
  styleUrls: ['./displaycourses.component.css']
})
export class DisplaycoursesComponent implements OnInit {

  constructor(private service : CourseServiceService) { }
  
  courses:any;

  ngOnInit(): void {
     
     this.service.fetchdata().subscribe(data =>
      {
        this.courses = data;
      })

  }
 
 

}
